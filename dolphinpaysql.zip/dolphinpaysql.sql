-- --------------------------------------------------------
-- Host:                         aaqa20uuz5nx5.cctjjxoxfho2.us-west-2.rds.amazonaws.com
-- Versione server:              5.7.22-log - Source distribution
-- S.O. server:                  Linux
-- HeidiSQL Versione:            10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dump della struttura del database ebdb
CREATE DATABASE IF NOT EXISTS `ebdb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `ebdb`;

-- Dump della struttura di tabella ebdb.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_state` int(11) NOT NULL DEFAULT '1',
  `z_expected_end_prepare` timestamp NOT NULL,
  `z_closure_time` timestamp NOT NULL,
  `z_sum_optional_time` timestamp NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  KEY `FK_orders_orders_states` (`z_state`),
  CONSTRAINT `FK_orders_orders_states` FOREIGN KEY (`z_state`) REFERENCES `orders_states` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.orders: ~0 rows (circa)
DELETE FROM `orders`;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.orders_products
CREATE TABLE IF NOT EXISTS `orders_products` (
  `z_order` int(11) NOT NULL,
  `z_product` int(11) NOT NULL,
  `z_state` int(11) NOT NULL DEFAULT '1',
  `z_quantity` int(11) NOT NULL,
  `z_expected_start_prepare` timestamp NOT NULL,
  `z_expected_end_prepare` timestamp NOT NULL,
  `z_closure_time` timestamp NOT NULL,
  `z_sum_optional_time` timestamp NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_order`,`z_product`),
  KEY `FK_orders_products_products` (`z_product`),
  KEY `FK_orders_products_orders_states` (`z_state`),
  CONSTRAINT `FK_orders_products_orders` FOREIGN KEY (`z_order`) REFERENCES `orders` (`z_id`),
  CONSTRAINT `FK_orders_products_orders_states` FOREIGN KEY (`z_state`) REFERENCES `orders_states` (`z_id`),
  CONSTRAINT `FK_orders_products_products` FOREIGN KEY (`z_product`) REFERENCES `products` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.orders_products: ~0 rows (circa)
DELETE FROM `orders_products`;
/*!40000 ALTER TABLE `orders_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_products` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.orders_states
CREATE TABLE IF NOT EXISTS `orders_states` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_name` varchar(50) NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  UNIQUE KEY `z_name` (`z_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.orders_states: ~4 rows (circa)
DELETE FROM `orders_states`;
/*!40000 ALTER TABLE `orders_states` DISABLE KEYS */;
INSERT INTO `orders_states` (`z_id`, `z_name`, `z_creation_time`, `z_last_update_time`) VALUES
	(1, 'STATE_NEW', '2019-05-15 09:59:37', '2019-05-15 09:59:37'),
	(2, 'STATE_PREPARE', '2019-05-15 09:59:56', '2019-05-15 09:59:56'),
	(3, 'STATE_READY', '2019-05-15 10:00:10', '2019-05-15 10:00:10'),
	(4, 'STATE_CLOSED', '2019-05-15 10:00:23', '2019-05-15 10:00:23');
/*!40000 ALTER TABLE `orders_states` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.platforms_partnerships
CREATE TABLE IF NOT EXISTS `platforms_partnerships` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_user` int(11) NOT NULL,
  `z_role` int(11) NOT NULL DEFAULT '3',
  `z_stand` int(11) NOT NULL,
  `z_name` varchar(50) NOT NULL,
  `z_state_on` binary(1) NOT NULL DEFAULT '1' COMMENT '0 = false, 1 = true',
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  KEY `FK_platforms_partnerships_users` (`z_user`),
  KEY `FK_platforms_partnerships_platforms_roles` (`z_role`),
  KEY `FK_platforms_partnerships_stands` (`z_stand`),
  CONSTRAINT `FK_platforms_partnerships_platforms_roles` FOREIGN KEY (`z_role`) REFERENCES `platforms_roles` (`z_id`),
  CONSTRAINT `FK_platforms_partnerships_stands` FOREIGN KEY (`z_stand`) REFERENCES `stands` (`z_id`),
  CONSTRAINT `FK_platforms_partnerships_users` FOREIGN KEY (`z_user`) REFERENCES `users` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.platforms_partnerships: ~0 rows (circa)
DELETE FROM `platforms_partnerships`;
/*!40000 ALTER TABLE `platforms_partnerships` DISABLE KEYS */;
/*!40000 ALTER TABLE `platforms_partnerships` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.platforms_permissions
CREATE TABLE IF NOT EXISTS `platforms_permissions` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_name` varchar(50) NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  UNIQUE KEY `z_name` (`z_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.platforms_permissions: ~0 rows (circa)
DELETE FROM `platforms_permissions`;
/*!40000 ALTER TABLE `platforms_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `platforms_permissions` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.platforms_permissions_and_roles
CREATE TABLE IF NOT EXISTS `platforms_permissions_and_roles` (
  `z_role` int(11) NOT NULL,
  `z_permission` int(11) NOT NULL,
  PRIMARY KEY (`z_role`,`z_permission`),
  KEY `FK_platforms_permissions_and_roles_platforms_permissions` (`z_permission`),
  CONSTRAINT `FK_platforms_permissions_and_roles_platforms_permissions` FOREIGN KEY (`z_permission`) REFERENCES `platforms_permissions` (`z_id`),
  CONSTRAINT `FK_platforms_permissions_and_roles_platforms_roles` FOREIGN KEY (`z_role`) REFERENCES `platforms_roles` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.platforms_permissions_and_roles: ~0 rows (circa)
DELETE FROM `platforms_permissions_and_roles`;
/*!40000 ALTER TABLE `platforms_permissions_and_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `platforms_permissions_and_roles` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.platforms_roles
CREATE TABLE IF NOT EXISTS `platforms_roles` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_name` varchar(50) NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  UNIQUE KEY `z_name` (`z_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.platforms_roles: ~2 rows (circa)
DELETE FROM `platforms_roles`;
/*!40000 ALTER TABLE `platforms_roles` DISABLE KEYS */;
INSERT INTO `platforms_roles` (`z_id`, `z_name`, `z_creation_time`, `z_last_update_time`) VALUES
	(1, 'ROLE_STANDARD_USER', '2019-05-12 11:19:45', '2019-05-12 11:20:14'),
	(2, 'ROLE_ADMIN_GUEST', '2019-05-12 11:20:37', '2019-05-12 11:20:37'),
	(3, 'ROLE_ADMIN', '2019-05-12 11:20:37', '2019-05-12 11:20:37');
/*!40000 ALTER TABLE `platforms_roles` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.platforms_standards
CREATE TABLE IF NOT EXISTS `platforms_standards` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_role` int(11) NOT NULL DEFAULT '1',
  `z_name` varchar(50) NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  UNIQUE KEY `z_name` (`z_name`),
  KEY `FK_platforms_standards_platforms_roles` (`z_role`),
  CONSTRAINT `FK_platforms_standards_platforms_roles` FOREIGN KEY (`z_role`) REFERENCES `platforms_roles` (`z_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.platforms_standards: ~1 rows (circa)
DELETE FROM `platforms_standards`;
/*!40000 ALTER TABLE `platforms_standards` DISABLE KEYS */;
INSERT INTO `platforms_standards` (`z_id`, `z_role`, `z_name`, `z_creation_time`, `z_last_update_time`) VALUES
	(2, 1, 'PLATFORM_STANDARD_USER', '2019-05-12 11:30:08', '2019-05-12 11:30:08');
/*!40000 ALTER TABLE `platforms_standards` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.platforms_subscribers
CREATE TABLE IF NOT EXISTS `platforms_subscribers` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_user` int(11) NOT NULL,
  `z_role` int(11) NOT NULL DEFAULT '2',
  `z_stand_room` int(11) NOT NULL,
  `z_name` varchar(50) NOT NULL,
  `z_state_on` binary(1) NOT NULL DEFAULT '1' COMMENT '0 = false, 1 = true',
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  KEY `FK_platforms_subscribers_users` (`z_user`),
  KEY `FK_platforms_subscribers_platforms_roles` (`z_role`),
  KEY `FK_platforms_subscribers_stands_rooms` (`z_stand_room`),
  CONSTRAINT `FK_platforms_subscribers_platforms_roles` FOREIGN KEY (`z_role`) REFERENCES `platforms_roles` (`z_id`),
  CONSTRAINT `FK_platforms_subscribers_stands_rooms` FOREIGN KEY (`z_stand_room`) REFERENCES `stands_rooms` (`z_id`),
  CONSTRAINT `FK_platforms_subscribers_users` FOREIGN KEY (`z_user`) REFERENCES `users` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.platforms_subscribers: ~0 rows (circa)
DELETE FROM `platforms_subscribers`;
/*!40000 ALTER TABLE `platforms_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `platforms_subscribers` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.products
CREATE TABLE IF NOT EXISTS `products` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_stand` int(11) NOT NULL,
  `z_type` int(11) NOT NULL,
  `z_brand` int(11) NOT NULL,
  `z_name` varchar(50) NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  UNIQUE KEY `z_type_z_brand_z_name` (`z_type`,`z_brand`,`z_stand`,`z_name`),
  KEY `FK_products_products_brands` (`z_brand`),
  KEY `FK_products_stands` (`z_stand`),
  CONSTRAINT `FK_products_products_brands` FOREIGN KEY (`z_brand`) REFERENCES `products_brands` (`z_id`),
  CONSTRAINT `FK_products_products_types` FOREIGN KEY (`z_type`) REFERENCES `products_types` (`z_id`),
  CONSTRAINT `FK_products_stands` FOREIGN KEY (`z_stand`) REFERENCES `stands` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.products: ~0 rows (circa)
DELETE FROM `products`;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.products_brands
CREATE TABLE IF NOT EXISTS `products_brands` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.products_brands: ~0 rows (circa)
DELETE FROM `products_brands`;
/*!40000 ALTER TABLE `products_brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_brands` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.products_types
CREATE TABLE IF NOT EXISTS `products_types` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_category` int(11) NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  KEY `FK_products_types_products_types_categories` (`z_category`),
  CONSTRAINT `FK_products_types_products_types_categories` FOREIGN KEY (`z_category`) REFERENCES `products_types_categories` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.products_types: ~0 rows (circa)
DELETE FROM `products_types`;
/*!40000 ALTER TABLE `products_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_types` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.products_types_categories
CREATE TABLE IF NOT EXISTS `products_types_categories` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.products_types_categories: ~0 rows (circa)
DELETE FROM `products_types_categories`;
/*!40000 ALTER TABLE `products_types_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_types_categories` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.stands
CREATE TABLE IF NOT EXISTS `stands` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.stands: ~0 rows (circa)
DELETE FROM `stands`;
/*!40000 ALTER TABLE `stands` DISABLE KEYS */;
/*!40000 ALTER TABLE `stands` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.stands_rooms
CREATE TABLE IF NOT EXISTS `stands_rooms` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_stand` int(11) NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  KEY `FK_stands_rooms_stands` (`z_stand`),
  CONSTRAINT `FK_stands_rooms_stands` FOREIGN KEY (`z_stand`) REFERENCES `stands` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.stands_rooms: ~0 rows (circa)
DELETE FROM `stands_rooms`;
/*!40000 ALTER TABLE `stands_rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `stands_rooms` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.stands_rooms_categories
CREATE TABLE IF NOT EXISTS `stands_rooms_categories` (
  `z_room` int(11) NOT NULL,
  `z_product_type_category` int(11) NOT NULL,
  PRIMARY KEY (`z_room`,`z_product_type_category`),
  KEY `FK_stands_rooms_categories_products_types_categories` (`z_product_type_category`),
  CONSTRAINT `FK_stands_rooms_categories_products_types_categories` FOREIGN KEY (`z_product_type_category`) REFERENCES `products_types_categories` (`z_id`),
  CONSTRAINT `FK_stands_rooms_categories_stands_rooms` FOREIGN KEY (`z_room`) REFERENCES `stands_rooms` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.stands_rooms_categories: ~0 rows (circa)
DELETE FROM `stands_rooms_categories`;
/*!40000 ALTER TABLE `stands_rooms_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `stands_rooms_categories` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.users
CREATE TABLE IF NOT EXISTS `users` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_username` varchar(50) NOT NULL DEFAULT '0',
  `z_email` varchar(50) NOT NULL DEFAULT '0',
  `z_standard_platform` int(11) NOT NULL DEFAULT '2',
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  UNIQUE KEY `username_email` (`z_username`,`z_email`),
  KEY `FK_users_platforms_standards` (`z_standard_platform`),
  CONSTRAINT `FK_users_platforms_standards` FOREIGN KEY (`z_standard_platform`) REFERENCES `platforms_standards` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.users: ~0 rows (circa)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dump della struttura di tabella ebdb.users_devices
CREATE TABLE IF NOT EXISTS `users_devices` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `z_user` int(11) NOT NULL,
  `z_firebase_token` text NOT NULL,
  `z_creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `z_last_update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`z_id`),
  KEY `FK_users_devices_users` (`z_user`),
  CONSTRAINT `FK_users_devices_users` FOREIGN KEY (`z_user`) REFERENCES `users` (`z_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dump dei dati della tabella ebdb.users_devices: ~0 rows (circa)
DELETE FROM `users_devices`;
/*!40000 ALTER TABLE `users_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_devices` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
